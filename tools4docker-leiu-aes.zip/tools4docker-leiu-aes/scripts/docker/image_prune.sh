#!/bin/bash
docker image prune -f
