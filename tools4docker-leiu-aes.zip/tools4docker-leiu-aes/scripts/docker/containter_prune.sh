#!/bin/bash
docker container prune -f
