# force 64 bit usage
MTI_VCO_MODE=64
#MTI_VCO_MODE=
# questasim path
PATH=$PATH:/opt/mentor/questa/2020.4/questasim/linux_x86_64

# license mentor
LM_LICENSE_FILE=$LM_LICENSE_FILE:26150@aberdeen.zhaw.ch:26010@aberdeen.zhaw.ch

# questasim used system libraries
#LIBRARY_PATH=

export LM_LICENSE_FILE PATH MIT_VCO_MODE
